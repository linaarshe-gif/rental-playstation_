<?php
include 'db.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$console_id = $_GET['id'];
$sql = "SELECT * FROM consoles WHERE id = $console_id";
$result = $conn->query($sql);
$console = $result->fetch_assoc();

if (!$console) {
    die("Konsol tidak ditemukan.");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sewa <?php echo $console['name']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Formulir Peminjaman</h4>
                </div>
                <div class="card-body">
                    <h5><?php echo $console['name']; ?></h5>
                    <p class="text-muted">Harga: Rp <?php echo number_format($console['price_per_day'], 0, ',', '.'); ?> / hari</p>
                    
                    <!-- Pastikan bagian form di rent.php terlihat seperti ini -->
<form action="process_rent.php" method="POST">
    <input type="hidden" name="console_id" value="<?php echo $console['id']; ?>">
    <input type="hidden" name="price_per_day" value="<?php echo $console['price_per_day']; ?>">

    <div class="mb-3">
        <label class="form-label">Nama Lengkap</label>
        <input type="text" name="customer_name" class="form-control" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Nomor WhatsApp</label>
        <input type="text" name="customer_phone" class="form-control" required>
    </div>
    <div class="row">
        <div class="col-md-6 mb-3">
            <label class="form-label">Tanggal Mulai</label>
            <input type="date" name="start_date" class="form-control" required>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label">Tanggal Selesai</label>
            <input type="date" name="end_date" class="form-control" required>
        </div>
    </div>
    
    <button type="submit" class="btn btn-success w-100">Konfirmasi Peminjaman</button>
    <a href="index.php" class="btn btn-secondary w-100 mt-2">Batal</a>
</form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
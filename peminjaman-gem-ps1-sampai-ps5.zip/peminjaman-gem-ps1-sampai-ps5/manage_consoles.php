<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include 'auth.php';

// UBAH DARI require_admin() MENJADI require_staff()
require_staff(); 

include 'db.php';

$edit_mode = false;
$console_data = ['id' => '', 'name' => '', 'generation' => '', 'price_per_day' => '', 'stock' => '', 'image_url' => ''];

// ... (Sisa kode form dan tabel di bawahnya TETAP SAMA seperti sebelumnya) ...
// Jika ada request edit
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM consoles WHERE id = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $edit_mode = true;
        $console_data = $result->fetch_assoc();
    }
}

// Hapus konsol
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    // Hapus file gambar jika ada
    $stmt = $conn->prepare("SELECT image_url FROM consoles WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    if ($res && file_exists($res['image_url'])) {
        unlink($res['image_url']);
    }
    
    $stmt = $conn->prepare("DELETE FROM consoles WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    header("Location: manage_consoles.php?success=deleted");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Konsol - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand mb-0 h1">🛠️ Dashboard Admin</span>
        <div>
            <a href="admin.php" class="btn btn-outline-light btn-sm me-2">Daftar Peminjaman</a>
            <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container">
    <div class="row">
        <!-- Form Tambah / Edit Konsol -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><?php echo $edit_mode ? 'Edit Konsol' : 'Tambah Konsol Baru'; ?></h5>
                </div>
                <div class="card-body">
                    <form action="process_console.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="edit_id" value="<?php echo $console_data['id']; ?>">
                        
                        <div class="mb-3">
                            <label class="form-label">Nama Konsol</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($console_data['name']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Generasi</label>
                            <select name="generation" class="form-select" required>
                                <option value="Gen 1" <?php if($console_data['generation']=='Gen 1') echo 'selected'; ?>>PlayStation 1</option>
                                <option value="Gen 2" <?php if($console_data['generation']=='Gen 2') echo 'selected'; ?>>PlayStation 2</option>
                                <option value="Gen 3" <?php if($console_data['generation']=='Gen 3') echo 'selected'; ?>>PlayStation 3</option>
                                <option value="Gen 4" <?php if($console_data['generation']=='Gen 4') echo 'selected'; ?>>PlayStation 4</option>
                                <option value="Gen 5" <?php if($console_data['generation']=='Gen 5') echo 'selected'; ?>>PlayStation 5</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Harga per Hari (Rp)</label>
                            <input type="number" name="price_per_day" class="form-control" value="<?php echo $console_data['price_per_day']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Stok Tersedia</label>
                            <input type="number" name="stock" class="form-control" value="<?php echo $console_data['stock']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Gambar Konsol</label>
                            <input type="file" name="image" class="form-control" accept="image/png, image/jpeg, image/webp">
                            <small class="text-muted">Format: JPG, PNG, WEBP. Maksimal 2MB.</small>
                            <?php if ($edit_mode && $console_data['image_url']): ?>
                                <img src="<?php echo htmlspecialchars($console_data['image_url']); ?>" class="img-thumbnail mt-2" style="max-height: 100px;">
                            <?php endif; ?>
                        </div>
                        
                        <button type="submit" class="btn btn-success w-100"><?php echo $edit_mode ? 'Update Konsol' : 'Simpan Konsol'; ?></button>
                        <?php if ($edit_mode): ?>
                            <a href="manage_consoles.php" class="btn btn-secondary w-100 mt-2">Batal</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <!-- Tabel Daftar Konsol -->
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-secondary text-white">
                    <h5 class="mb-0">Daftar Konsol</h5>
                </div>
                <div class="card-body">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Gambar</th>
                                <th>Nama</th>
                                <th>Harga/Hari</th>
                                <th>Stok</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("SELECT * FROM consoles ORDER BY id ASC");
                            while ($row = $result->fetch_assoc()):
                                $img = $row['image_url'] ? $row['image_url'] : 'https://via.placeholder.com/80x60?text=No+Image';
                            ?>
                            <tr>
                                <td><img src="<?php echo htmlspecialchars($img); ?>" class="img-thumbnail" style="max-height: 60px;"></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($row['name']); ?></strong><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($row['generation']); ?></small>
                                </td>
                                <td>Rp <?php echo number_format($row['price_per_day'], 0, ',', '.'); ?></td>
                                <td><?php echo $row['stock']; ?></td>
                                <td>
                                    <a href="manage_consoles.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="manage_consoles.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus konsol ini?')">Hapus</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
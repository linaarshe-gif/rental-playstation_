<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include 'auth.php';
require_admin(); // Hanya Admin
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rental_id = (int)$_POST['rental_id'];
    $action = $_POST['action']; // 'accept' atau 'reject'
    
    if ($action === 'accept') {
        $console_id = (int)$_POST['console_id'];
        
        // 1. Cek apakah stok masih tersedia
        $stmt = $conn->prepare("SELECT stock FROM consoles WHERE id = ?");
        $stmt->bind_param("i", $console_id);
        $stmt->execute();
        $stock_data = $stmt->get_result()->fetch_assoc();
        
        if ($stock_data['stock'] <= 0) {
            echo "<script>alert('Gagal menerima! Stok konsol ini sudah habis.'); window.location.href='admin.php';</script>";
            exit();
        }

        // 2. Update status sewa menjadi 'Active'
        $stmt = $conn->prepare("UPDATE rentals SET status = 'Active' WHERE id = ?");
        $stmt->bind_param("i", $rental_id);
        $stmt->execute();

        // 3. Kurangi stok konsol sebanyak 1
        $stmt = $conn->prepare("UPDATE consoles SET stock = stock - 1 WHERE id = ?");
        $stmt->bind_param("i", $console_id);
        $stmt->execute();

        echo "<script>alert('Sewa berhasil DITERIMA dan stok telah dikurangi.'); window.location.href='admin.php';</script>";
        
    } elseif ($action === 'reject') {
        // Update status sewa menjadi 'Cancelled' (Stok tidak berubah karena belum dikurangi)
        $stmt = $conn->prepare("UPDATE rentals SET status = 'Cancelled' WHERE id = ?");
        $stmt->bind_param("i", $rental_id);
        
        if ($stmt->execute()) {
            echo "<script>alert('Sewa berhasil DITOLAK.'); window.location.href='admin.php';</script>";
        } else {
            echo "Error: " . $conn->error;
        }
    }
    
    $stmt->close();
    $conn->close();
} else {
    header("Location: admin.php");
}
?>
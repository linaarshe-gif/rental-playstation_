<?php
session_start();
include 'db.php';

// Proteksi: Hanya Admin dan Petugas yang bisa akses
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'petugas'])) {
    header("Location: index.php?error=Akses ditolak");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog Admin - Rental PS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand mb-0 h1">📚 Katalog Admin (Semua Unit)</span>
        <div>
            <a href="admin.php" class="btn btn-outline-light btn-sm me-2">Dashboard Admin</a>
            <a href="manage_units.php" class="btn btn-warning btn-sm me-2">Kelola Unit</a>
            <a href="stock_management.php" class="btn btn-info btn-sm me-2">Kelola Stok</a>
            <a href="index.php" class="btn btn-outline-light btn-sm">Lihat Katalog User</a>
        </div>
    </div>
</nav>

<div class="container">
    <div class="alert alert-info">
        <strong>ℹ️ Info:</strong> Halaman ini menampilkan SEMUA konsol termasuk yang stok habis atau disembunyikan dari user.
    </div>

    <h3 class="mb-4">🎮 Daftar Semua Konsol</h3>
    <div class="row">
        <?php
        // Tampilkan SEMUA konsol (tidak filter stock atau is_visible)
        $sql = "SELECT * FROM consoles ORDER BY id ASC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $img_src = !empty($row["image_url"]) && file_exists($row["image_url"]) 
                           ? $row["image_url"] 
                           : "https://via.placeholder.com/300x200?text=PlayStation";
                
                // Tentukan badge status
                $status_badge = '';
                if ($row['stock'] == 0) {
                    $status_badge = '<span class="badge bg-danger">Stok Habis</span>';
                } elseif ($row['is_visible'] == 0) {
                    $status_badge = '<span class="badge bg-secondary">Disembunyikan</span>';
                } else {
                    $status_badge = '<span class="badge bg-success">Tersedia</span>';
                }

                echo '<div class="col-md-4 mb-4">';
                echo '  <div class="card h-100 shadow-sm">';
                echo '    <img src="'.htmlspecialchars($img_src).'" class="card-img-top" alt="'.htmlspecialchars($row["name"]).'" style="height: 200px; object-fit: cover;">';
                echo '    <div class="card-body">';
                echo '      <h5 class="card-title">'.htmlspecialchars($row["name"]).'</h5>';
                echo '      <p class="card-text text-muted">Generasi: '.htmlspecialchars($row["generation"]).'</p>';
                echo '      <h4 class="text-primary">Rp '.number_format($row["price_per_day"], 0, ',', '.').'<small class="text-muted fs-6"> / hari</small></h4>';
                echo '      <p class="mb-2">Stok: <strong>'.$row["stock"].' unit</strong></p>';
                echo '      <div class="mb-2">'.$status_badge.'</div>';
                echo '      <div class="d-grid gap-2">';
                echo '        <a href="manage_units.php?edit='.$row["id"].'" class="btn btn-sm btn-warning">✏️ Edit</a>';
                echo '        <a href="rent.php?id='.$row["id"].'" class="btn btn-sm btn-outline-primary" target="_blank">👁️ Lihat User View</a>';
                echo '      </div>';
                echo '    </div>';
                echo '  </div>';
                echo '</div>';
            }
        } else {
            echo '<p class="text-center text-muted">Belum ada data konsol.</p>';
        }
        ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
session_start();
include 'db.php';

// Proteksi: Hanya Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php?error=Akses ditolak");
    exit();
}

// --- LOGIKA PROSES ADMIN (TERIMA/TOLAK) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    $rental_id = (int)$_POST['rental_id'];
    $action = $_POST['action'];

    if ($action === 'accept_rent') {
        // 1. Terima Sewa Baru -> Kurangi Stok
        $console_id = (int)$_POST['console_id'];
        $conn->query("UPDATE rentals SET status = 'Active' WHERE id = $rental_id");
        $conn->query("UPDATE consoles SET stock = stock - 1 WHERE id = $console_id");
        header("Location: admin.php?msg=accepted");
        
    } elseif ($action === 'reject_rent') {
        // 2. Tolak Sewa -> Status Cancelled
        $conn->query("UPDATE rentals SET status = 'Cancelled' WHERE id = $rental_id");
        header("Location: admin.php?msg=rejected");

    } elseif ($action === 'approve_return') {
        // 3. TERIMA PENGEMBALIAN BARANG -> Tambah Stok & Status Returned
        $console_id = (int)$_POST['console_id'];
        $conn->query("UPDATE rentals SET status = 'Returned' WHERE id = $rental_id");
        $conn->query("UPDATE consoles SET stock = stock + 1 WHERE id = $console_id");
        header("Location: admin.php?msg=returned");
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand mb-0 h1">🛡️ Dashboard Admin</span>
        <div>
            <a href="index.php" class="btn btn-outline-light btn-sm me-2">Ke Katalog</a>
            <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container">
    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success">Aksi berhasil dilakukan!</div>
    <?php endif; ?>

    <h3 class="mb-4">Manajemen Sewa & Pengembalian</h3>
    
    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Penyewa</th>
                        <th>Konsol</th>
                        <th>Status</th>
                        <th>Bukti Bayar</th>
                        <th>Aksi Admin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT r.*, u.username, c.name as console_name, c.id as cid 
                            FROM rentals r 
                            JOIN users u ON r.user_id = u.id 
                            JOIN consoles c ON r.console_id = c.id 
                            ORDER BY r.created_at DESC";
                    $result = $conn->query($sql);

                    while($row = $result->fetch_assoc()) {
                        $badge = 'bg-secondary';
                        if ($row['status'] == 'Pending') $badge = 'bg-warning text-dark';
                        elseif ($row['status'] == 'Active') $badge = 'bg-primary';
                        elseif ($row['status'] == 'Return_Request') $badge = 'bg-info text-dark'; // Status Pengembalian
                        elseif ($row['status'] == 'Returned') $badge = 'bg-success';
                        elseif ($row['status'] == 'Cancelled') $badge = 'bg-danger';

                        $img_tag = empty($row['payment_proof']) ? '-' : '<a href="'.$row['payment_proof'].'" target="_blank"><img src="'.$row['payment_proof'].'" style="max-height:50px"></a>';

                        $action_html = '';
                        
                        // LOGIKA TOMBOL ADMIN
                        if ($row['status'] == 'Pending') {
                            $action_html = '
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="rental_id" value="'.$row['id'].'">
                                    <input type="hidden" name="console_id" value="'.$row['cid'].'">
                                    <input type="hidden" name="action" value="accept_rent">
                                    <button class="btn btn-sm btn-success">✅ Terima Sewa</button>
                                </form>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="rental_id" value="'.$row['id'].'">
                                    <input type="hidden" name="action" value="reject_rent">
                                    <button class="btn btn-sm btn-danger">❌ Tolak</button>
                                </form>';
                        } elseif ($row['status'] == 'Return_Request') {
                            // TOMBOL KHUSUS PENERIMAAN BARANG
                            $action_html = '
                                <div class="alert alert-info py-1 mb-1 small">User minta kembalikan barang</div>
                                <form method="POST">
                                    <input type="hidden" name="rental_id" value="'.$row['id'].'">
                                    <input type="hidden" name="console_id" value="'.$row['cid'].'">
                                    <input type="hidden" name="action" value="approve_return">
                                    <button class="btn btn-sm btn-primary w-100">✔️ Terima Barang & Tambah Stok</button>
                                </form>';
                        } elseif ($row['status'] == 'Active') {
                            $action_html = '<span class="text-muted">Sedang disewa user</span>';
                        } else {
                            $action_html = '<span class="text-muted">Selesai/Batal</span>';
                        }

                        echo "<tr>
                                <td>#{$row['id']}</td>
                                <td>{$row['username']}<br><small>{$row['customer_phone']}</small></td>
                                <td>{$row['console_name']}</td>
                                <td><span class='badge $badge'>{$row['status']}</span></td>
                                <td>$img_tag</td>
                                <td>$action_html</td>
                              </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include 'auth.php';
require_login();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rental_id = (int)$_POST['rental_id'];
    $user_id = $_SESSION['user_id'];
    $return_proof_url = '';
    $error = '';

    // 1. Validasi Kepemilikan (Pastikan user ini yang menyewa)
    $stmt = $conn->prepare("SELECT status FROM rentals WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $rental_id, $user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();

    if (!$res || $res['status'] !== 'Active') {
        die("<script>alert('Transaksi tidak valid atau sudah selesai.'); window.location.href='my_rentals.php';</script>");
    }

    // 2. Proses Upload Foto Bukti
    if (isset($_FILES['return_proof']) && $_FILES['return_proof']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

        $ext = strtolower(pathinfo($_FILES['return_proof']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png']) && $_FILES['return_proof']['size'] <= 2000000) {
            $new_name = uniqid('return_', true) . '.' . $ext;
            $target_file = $target_dir . $new_name;
            
            if (move_uploaded_file($_FILES['return_proof']['tmp_name'], $target_file)) {
                $return_proof_url = $target_file;
            } else {
                $error = "Gagal mengunggah foto.";
            }
        } else {
            $error = "Format file salah atau ukuran > 2MB.";
        }
    } else {
        $error = "Foto bukti wajib diupload!";
    }

    if ($error) {
        die("<script>alert('$error'); window.history.back();</script>");
    }

    // 3. Update Status ke 'Returned'
    $stmt = $conn->prepare("UPDATE rentals SET status = 'Returned', return_proof = ? WHERE id = ? AND user_id = ?");
    $stmt->bind_param("sii", $return_proof_url, $rental_id, $user_id);

    if ($stmt->execute()) {
        // Opsional: Tambah stok kembali secara otomatis
        // $conn->query("UPDATE consoles c JOIN rentals r ON c.id = r.console_id SET c.stock = c.stock + 1 WHERE r.id = $rental_id");
        
        echo "<script>alert('Pengembalian berhasil dikonfirmasi! Terima kasih telah menyewa.'); window.location.href='my_rentals.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    header("Location: my_rentals.php");
}
?>
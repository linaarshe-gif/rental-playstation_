<?php
session_start();
include 'db.php';

// 1. Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// 2. Blokir akses jika bukan metode POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Akses tidak diizinkan. <a href='index.php'>Kembali ke Katalog</a>");
}

// 3. Ambil dan bersihkan data dari form
$user_id = $_SESSION['user_id'];
$console_id = isset($_POST['console_id']) ? (int)$_POST['console_id'] : 0;
$customer_name = isset($_POST['customer_name']) ? trim($_POST['customer_name']) : '';
$customer_phone = isset($_POST['customer_phone']) ? trim($_POST['customer_phone']) : '';
$start_date = isset($_POST['start_date']) ? $_POST['start_date'] : '';
$end_date = isset($_POST['end_date']) ? $_POST['end_date'] : '';
$price_per_day = isset($_POST['price_per_day']) ? (float)$_POST['price_per_day'] : 0;

// 4. Validasi data tidak boleh kosong
if (empty($customer_name) || empty($customer_phone) || empty($start_date) || empty($end_date)) {
    die("<script>alert('Semua field wajib diisi!'); window.history.back();</script>");
}

// 5. Validasi tanggal (Tanggal selesai tidak boleh sebelum tanggal mulai)
if (strtotime($end_date) < strtotime($start_date)) {
    die("<script>alert('Tanggal selesai tidak boleh lebih awal dari tanggal mulai!'); window.history.back();</script>");
}

// 6. Ambil data konsol dari database untuk validasi
$stmt = $conn->prepare("SELECT name, price_per_day, stock FROM consoles WHERE id = ?");
$stmt->bind_param("i", $console_id);
$stmt->execute();
$result = $stmt->get_result();
$console = $result->fetch_assoc();

if (!$console) {
    die("<script>alert('Konsol tidak ditemukan!'); window.location.href='index.php';</script>");
}

// 7. Hitung total hari dan total harga
$date1 = new DateTime($start_date);
$date2 = new DateTime($end_date);
$interval = $date1->diff($date2);
$total_days = $interval->days;

if ($total_days == 0) {
    $total_days = 1; // Minimal sewa 1 hari
}

$total_price = $total_days * $console['price_per_day'];

// 8. Proses Upload Bukti Pembayaran (Opsional tapi disarankan)
$payment_proof_url = '';
if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] == 0) {
    $target_dir = "uploads/";
    
    // Buat folder uploads jika belum ada
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $file_name = $_FILES['payment_proof']['name'];
    $file_tmp = $_FILES['payment_proof']['tmp_name'];
    $file_size = $_FILES['payment_proof']['size'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    $allowed_ext = ['jpg', 'jpeg', 'png'];

    if (!in_array($file_ext, $allowed_ext)) {
        die("<script>alert('Hanya file JPG, JPEG, & PNG yang diperbolehkan untuk bukti bayar!'); window.history.back();</script>");
    } elseif ($file_size > 2000000) { // Maksimal 2MB
        die("<script>alert('Ukuran file bukti bayar terlalu besar. Maksimal 2MB!'); window.history.back();</script>");
    } else {
        // Buat nama file unik agar tidak tertimpa
        $new_file_name = uniqid('bukti_', true) . '.' . $file_ext;
        $target_file = $target_dir . $new_file_name;

        if (move_uploaded_file($file_tmp, $target_file)) {
            $payment_proof_url = $target_file;
        } else {
            die("<script>alert('Gagal mengunggah foto bukti bayar. Periksa izin folder uploads.'); window.history.back();</script>");
        }
    }
}

// 9. Simpan data peminjaman ke database
// Status default adalah 'Pending' menunggu konfirmasi Admin
$stmt = $conn->prepare("INSERT INTO rentals (user_id, console_id, customer_name, customer_phone, start_date, end_date, total_days, total_price, status, payment_proof) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?)");

// Bind parameter: i=int, s=string, d=double/decimal
$stmt->bind_param("iissssids", $user_id, $console_id, $customer_name, $customer_phone, $start_date, $end_date, $total_days, $total_price, $payment_proof_url);

if ($stmt->execute()) {
    // Berhasil disimpan, arahkan ke halaman riwayat dengan pesan sukses
    $console_name = htmlspecialchars($console['name']);
    $formatted_price = number_format($total_price, 0, ',', '.');
    
    echo "<script>
            alert('✅ Peminjaman berhasil diajukan!\\n\\nDetail:\\n- Konsol: $console_name\\n- Durasi: $total_days Hari\\n- Total: Rp $formatted_price\\n\\nSilakan tunggu konfirmasi dari Admin/Petugas di menu Riwayat Sewa.');
            window.location.href = 'my_rentals.php';
          </script>";
} else {
    // Gagal menyimpan
    die("Gagal menyimpan data peminjaman: " . $stmt->error . "<br><a href='rent.php?id=$console_id'>Kembali ke Form</a>");
}

$stmt->close();
$conn->close();
?>
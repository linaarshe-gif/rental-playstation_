<?php
session_start();
include 'db.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental PlayStation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand mb-0 h1" href="index.php">🎮 Rental PlayStation</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <!-- Menu untuk User yang Sudah Login -->
                    <li class="nav-item">
                        <span class="nav-link text-white">Halo, <b><?php echo htmlspecialchars($_SESSION['username']); ?></b></span>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link text-light" href="my_rentals.php">📋 Riwayat Sewa Saya</a>
                    </li>

                    <!-- Menu Khusus Admin & Petugas -->
                    <?php if (in_array($_SESSION['role'], ['admin', 'petugas'])): ?>
                        <li class="nav-item">
                            <a class="nav-link text-info" href="admin_catalog.php">📚 Katalog Admin</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-warning" href="admin.php">Dashboard Admin</a>
                        </li>
                        <?php if (in_array($_SESSION['role'], ['admin', 'petugas'])): ?>
    <li class="nav-item">
        <a class="nav-link text-info fw-bold" href="stock_management.php">📦 Kelola Stok</a>
    </li>
    <li class="nav-item">
        <a class="nav-link text-warning" href="admin.php">Dashboard Admin</a>
    </li>
<?php endif; ?>
                    <?php endif; ?>

                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">Logout</a>
                    </li>

                <?php else: ?>
                    <!-- Menu untuk Pengunjung (Belum Login) -->
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container">
    <h2 class="text-center mb-4">Pilih Konsol Favorit Anda</h2>
    <div class="row">
        <?php
        // Menampilkan konsol yang stoknya > 0
        $sql = "SELECT * FROM consoles WHERE stock > 0 ORDER BY id ASC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $img_src = !empty($row["image_url"]) ? $row["image_url"] : "https://via.placeholder.com/300x200?text=PlayStation";
                
                echo '<div class="col-md-4 mb-4">';
                echo '  <div class="card h-100 shadow-sm">';
                echo '    <img src="'.htmlspecialchars($img_src).'" class="card-img-top" alt="'.htmlspecialchars($row["name"]).'" style="height: 200px; object-fit: cover;">';
                echo '    <div class="card-body">';
                echo '      <h5 class="card-title">'.htmlspecialchars($row["name"]).'</h5>';
                echo '      <p class="card-text text-muted">Generasi: '.htmlspecialchars($row["generation"]).'</p>';
                echo '      <h4 class="text-primary">Rp '.number_format($row["price_per_day"], 0, ',', '.').'<small class="text-muted fs-6"> / hari</small></h4>';
                echo '      <p class="text-success">Stok Tersedia: '.$row["stock"].' unit</p>';
                echo '      <a href="rent.php?id='.$row["id"].'" class="btn btn-primary w-100">Sewa Sekarang</a>';
                echo '    </div>';
                echo '  </div>';
                echo '</div>';
            }
        } else {
            echo '<p class="text-center text-muted">Tidak ada konsol yang tersedia saat ini.</p>';
        }
        ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
session_start();
include 'db.php';

// Proteksi Akses
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'petugas'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $console_id = (int)$_POST['console_id'];
    $action = $_POST['action']; 
    $qty = (int)$_POST['qty'];

    if ($qty <= 0) {
        die("<script>alert('Jumlah harus lebih dari 0!'); window.history.back();</script>");
    }

    if ($action === 'add') {
        // TAMBAH STOK
        $stmt = $conn->prepare("UPDATE consoles SET stock = stock + ? WHERE id = ?");
        $stmt->bind_param("ii", $qty, $console_id);
        $stmt->execute();
        header("Location: stock_management.php?msg=added");
        exit();

    } elseif ($action === 'reduce') {
        // KURANGI STOK (Cek dulu agar tidak minus)
        $check_stmt = $conn->prepare("SELECT stock FROM consoles WHERE id = ?");
        $check_stmt->bind_param("i", $console_id);
        $check_stmt->execute();
        $current_data = $check_stmt->get_result()->fetch_assoc();

        if ($current_data['stock'] < $qty) {
            // Stok tidak cukup
            header("Location: stock_management.php?msg=error");
            exit();
        } else {
            // Stok cukup, kurangi
            $stmt = $conn->prepare("UPDATE consoles SET stock = stock - ? WHERE id = ?");
            $stmt->bind_param("ii", $qty, $console_id);
            $stmt->execute();
            header("Location: stock_management.php?msg=reduced");
            exit();
        }
    }
} else {
    header("Location: stock_management.php");
}
?>
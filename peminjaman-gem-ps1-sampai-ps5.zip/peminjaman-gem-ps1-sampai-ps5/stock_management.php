<?php
session_start();
include 'db.php';

// Proteksi: Hanya Admin dan Petugas yang bisa akses
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'petugas'])) {
    header("Location: index.php?error=Akses ditolak. Hanya Admin/Petugas.");
    exit();
}

$msg = isset($_GET['msg']) ? $_GET['msg'] : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Stok - Rental PS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand mb-0 h1">📦 Kelola Stok Barang</span>
        <div>
            <a href="index.php" class="btn btn-outline-light btn-sm me-2">← Kembali ke Katalog</a>
            <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container">
    <?php if ($msg == 'added'): ?>
        <div class="alert alert-success alert-dismissible fade show">✅ <strong>Berhasil!</strong> Stok berhasil ditambahkan. <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php elseif ($msg == 'reduced'): ?>
        <div class="alert alert-info alert-dismissible fade show">ℹ️ <strong>Berhasil!</strong> Stok berhasil dikurangi. <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php elseif ($msg == 'error'): ?>
        <div class="alert alert-danger alert-dismissible fade show">❌ <strong>Gagal!</strong> Stok tidak bisa dikurangi karena jumlah yang diminta melebihi stok tersedia. <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Update Stok Konsol (PS1 - PS5)</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Nama Konsol</th>
                            <th>Generasi</th>
                            <th>Stok Saat Ini</th>
                            <th class="text-center" style="width: 40%;">Aksi Penambahan / Pengurangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $conn->query("SELECT * FROM consoles ORDER BY id ASC");
                        while ($row = $result->fetch_assoc()):
                        ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($row['name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($row['generation']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo $row['stock'] > 0 ? 'success' : 'danger'; ?> fs-6">
                                    <?php echo $row['stock']; ?> Unit
                                </span>
                            </td>
                            <td>
                                <form action="process_stock.php" method="POST" class="row g-2 align-items-center">
                                    <input type="hidden" name="console_id" value="<?php echo $row['id']; ?>">
                                    
                                    <div class="col-4">
                                        <select name="action" class="form-select form-select-sm" required>
                                            <option value="add">➕ Tambah</option>
                                            <option value="reduce">➖ Kurangi</option>
                                        </select>
                                    </div>
                                    <div class="col-4">
                                        <input type="number" name="qty" class="form-control form-control-sm" min="1" value="1" required>
                                    </div>
                                    <div class="col-4">
                                        <button type="submit" class="btn btn-sm btn-primary w-100">Update</button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$rental_id = (int)$_GET['id'];
$user_id = $_SESSION['user_id'];

// Cek apakah sewa ini milik user yang login dan statusnya masih 'Active'
$stmt = $conn->prepare("SELECT status FROM rentals WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $rental_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if ($data && $data['status'] == 'Active') {
    // Ubah status menjadi 'Return_Request'
    $update = $conn->prepare("UPDATE rentals SET status = 'Return_Request' WHERE id = ?");
    $update->bind_param("i", $rental_id);
    
    if ($update->execute()) {
        echo "<script>alert('Permintaan pengembalian berhasil dikirim! Silakan tunggu admin memverifikasi.'); window.location.href='my_rentals.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan sistem.'); window.location.href='my_rentals.php';</script>";
    }
} else {
    echo "<script>alert('Transaksi tidak valid atau status sewa sudah berubah.'); window.location.href='my_rentals.php';</script>";
}
?>
<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include 'auth.php';
require_staff(); // Hanya Admin & Petugas
include 'db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'toggle') {
    $id = (int)$_GET['id'];
    $conn->query("UPDATE consoles SET is_visible = NOT is_visible WHERE id = $id");
    header("Location: manage_units.php");
    exit;
}

if ($action === 'delete') {
    $id = (int)$_GET['id'];
    // Hapus file gambar jika ada
    $res = $conn->query("SELECT image_url FROM consoles WHERE id = $id")->fetch_assoc();
    if ($res && !empty($res['image_url']) && file_exists($res['image_url'])) {
        unlink($res['image_url']);
    }
    $conn->query("DELETE FROM consoles WHERE id = $id");
    header("Location: manage_units.php?msg=deleted");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && in_array($action, ['add', 'edit'])) {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $name = trim($_POST['name']);
    $generation = $_POST['generation'];
    $price = (float)$_POST['price_per_day'];
    $stock = (int)$_POST['stock'];
    $image_url = '';
    $error = '';

    // Proses Upload Gambar
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp']) && $_FILES['image']['size'] <= 2000000) {
            $new_name = uniqid('unit_', true) . '.' . $ext;
            $target_file = $target_dir . $new_name;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image_url = $target_file;
                // Hapus gambar lama jika mode edit
                if ($action === 'edit' && $id > 0) {
                    $old_img = $conn->query("SELECT image_url FROM consoles WHERE id = $id")->fetch_assoc()['image_url'];
                    if ($old_img && file_exists($old_img)) unlink($old_img);
                }
            } else {
                $error = "Gagal mengunggah gambar.";
            }
        } else {
            $error = "Format gambar tidak valid atau ukuran > 2MB.";
        }
    }

    if ($error) {
        die("<script>alert('$error'); window.history.back();</script>");
    }

    if ($action === 'add') {
        $stmt = $conn->prepare("INSERT INTO consoles (name, generation, price_per_day, stock, image_url, is_visible) VALUES (?, ?, ?, ?, ?, 1)");
        $stmt->bind_param("ssdss", $name, $generation, $price, $stock, $image_url);
        $msg = "Unit berhasil ditambahkan!";
    } else {
        if ($image_url) {
            $stmt = $conn->prepare("UPDATE consoles SET name=?, generation=?, price_per_day=?, stock=?, image_url=? WHERE id=?");
            $stmt->bind_param("ssdssi", $name, $generation, $price, $stock, $image_url, $id);
        } else {
            $stmt = $conn->prepare("UPDATE consoles SET name=?, generation=?, price_per_day=?, stock=? WHERE id=?");
            $stmt->bind_param("ssdsi", $name, $generation, $price, $stock, $id);
        }
        $msg = "Unit berhasil diperbarui!";
    }

    if ($stmt->execute()) {
        echo "<script>alert('$msg'); window.location.href='manage_units.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
    exit;
}

header("Location: manage_units.php");
?>
<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include 'auth.php';

// UBAH DARI require_admin() MENJADI require_staff()
require_staff(); 

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $edit_id = isset($_POST['edit_id']) ? (int)$_POST['edit_id'] : 0;
    $name = trim($_POST['name']);
    $generation = $_POST['generation'];
    $price_per_day = (float)$_POST['price_per_day'];
    $stock = (int)$_POST['stock'];
    
    $image_url = '';
    $upload_error = '';

    // --- PROSES UPLOAD GAMBAR ---
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "uploads/";
        
        // Pastikan folder uploads ada, jika tidak, buat otomatis
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $file_name = $_FILES['image']['name'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'webp'];

        if (!in_array($file_ext, $allowed_ext)) {
            $upload_error = "Hanya file JPG, JPEG, PNG, & WEBP yang diperbolehkan.";
        } elseif ($file_size > 2000000) { // Maksimal 2MB
            $upload_error = "Ukuran file terlalu besar. Maksimal 2MB.";
        } else {
            // Buat nama file unik
            $new_file_name = uniqid('ps_', true) . '.' . $file_ext;
            $target_file = $target_dir . $new_file_name;

            if (move_uploaded_file($file_tmp, $target_file)) {
                $image_url = $target_file;
                
                // Jika mode edit, hapus gambar lama agar tidak menumpuk
                if ($edit_id > 0) {
                    $stmt = $conn->prepare("SELECT image_url FROM consoles WHERE id = ?");
                    $stmt->bind_param("i", $edit_id);
                    $stmt->execute();
                    $old_img = $stmt->get_result()->fetch_assoc()['image_url'];
                    if ($old_img && file_exists($old_img) && strpos($old_img, 'placeholder') === false) {
                        unlink($old_img);
                    }
                }
            } else {
                $upload_error = "Gagal mengunggah gambar. Periksa izin folder 'uploads'.";
            }
        }
    }

    if ($upload_error) {
        die("<script>alert('$upload_error'); window.history.back();</script>");
    }

    // --- SIMPAN KE DATABASE ---
    if ($edit_id > 0) {
        // Mode UPDATE
        if ($image_url) {
            $stmt = $conn->prepare("UPDATE consoles SET name=?, generation=?, price_per_day=?, stock=?, image_url=? WHERE id=?");
            $stmt->bind_param("ssdssi", $name, $generation, $price_per_day, $stock, $image_url, $edit_id);
        } else {
            $stmt = $conn->prepare("UPDATE consoles SET name=?, generation=?, price_per_day=?, stock=? WHERE id=?");
            $stmt->bind_param("ssdsi", $name, $generation, $price_per_day, $stock, $edit_id);
        }
        $msg = "Data & Gambar konsol berhasil diperbarui!";
    } else {
        // Mode INSERT (Tambah Baru)
        $stmt = $conn->prepare("INSERT INTO consoles (name, generation, price_per_day, stock, image_url) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdss", $name, $generation, $price_per_day, $stock, $image_url);
        $msg = "Konsol baru berhasil ditambahkan beserta gambarnya!";
    }

    if ($stmt->execute()) {
        echo "<script>alert('$msg'); window.location.href='manage_consoles.php';</script>";
    } else {
        echo "Error Database: " . $conn->error;
    }
    
    $stmt->close();
    $conn->close();
} else {
    header("Location: manage_consoles.php");
}
?>
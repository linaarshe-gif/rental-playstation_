<?php
session_start();
include 'db.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Sewa Saya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="index.php">🎮 Rental PlayStation</a>
        <span class="navbar-text text-white">Halo, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
    </div>
</nav>

<div class="container">
    <h3 class="mb-4">📋 Riwayat Peminjaman Saya</h3>
    
    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Konsol</th>
                        <th>Tgl Mulai</th>
                        <th>Tgl Selesai</th>
                        <th>Total Harga</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT r.*, c.name as console_name FROM rentals r 
                            JOIN consoles c ON r.console_id = c.id 
                            WHERE r.user_id = ? ORDER BY r.created_at DESC";
                    
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $user_id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            $status_badge = '';
                            $action_btn = '';

                            // Logika Tampilan Berdasarkan Status
                            if ($row['status'] == 'Pending') {
                                $status_badge = '<span class="badge bg-warning text-dark">Menunggu Konfirmasi Admin</span>';
                            } elseif ($row['status'] == 'Active') {
                                $status_badge = '<span class="badge bg-primary">Sedang Disewa</span>';
                                // Tombol Pengembalian
                                $action_btn = '<a href="process_return_request.php?id='.$row['id'].'" class="btn btn-sm btn-success" onclick="return confirm(\'Yakin ingin mengajukan pengembalian barang ini?\')">📤 Ajukan Pengembalian</a>';
                            } elseif ($row['status'] == 'Return_Request') {
                                $status_badge = '<span class="badge bg-info text-dark">Menunggu Verifikasi Admin</span>';
                                $action_btn = '<small class="text-muted">Sedang diverifikasi...</small>';
                            } elseif ($row['status'] == 'Returned') {
                                $status_badge = '<span class="badge bg-success">Selesai / Dikembalikan</span>';
                            } elseif ($row['status'] == 'Cancelled') {
                                $status_badge = '<span class="badge bg-danger">Dibatalkan</span>';
                            }

                            echo "<tr>";
                            echo "<td><strong>".htmlspecialchars($row['console_name'])."</strong></td>";
                            echo "<td>".$row['start_date']."</td>";
                            echo "<td>".$row['end_date']."</td>";
                            echo "<td>Rp ".number_format($row['total_price'], 0, ',', '.')."</td>";
                            echo "<td>$status_badge</td>";
                            echo "<td>$action_btn</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center py-4'>Anda belum memiliki riwayat peminjaman.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <a href="index.php" class="btn btn-secondary mt-3">← Kembali ke Katalog</a>
</div>

</body>
</html>
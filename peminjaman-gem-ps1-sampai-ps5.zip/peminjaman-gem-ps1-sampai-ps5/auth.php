<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function require_login() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php?error=Silakan login terlebih dahulu");
        exit();
    }
}

function require_admin() {
    require_login();
    if ($_SESSION['role'] !== 'admin') {
        header("Location: index.php?error=Akses ditolak. Hanya admin yang boleh masuk.");
        exit();
    }
}

// Izinkan Admin DAN Petugas
function require_staff() {
    require_login();
    $allowed_roles = ['admin', 'petugas'];
    if (!in_array($_SESSION['role'], $allowed_roles)) {
        header("Location: index.php?error=Akses ditolak. Hanya Admin atau Petugas yang boleh masuk.");
        exit();
    }
}
?>
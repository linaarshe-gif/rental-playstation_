<!-- Modal Pengembalian -->
<div class="modal fade" id="returnModal<?php echo $row['id']; ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Konfirmasi Pengembalian: <?php echo htmlspecialchars($row['console_name']); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="process_return.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="rental_id" value="<?php echo $row['id']; ?>">
                    <p class="text-muted">Silakan upload foto kondisi konsol saat dikembalikan sebagai bukti.</p>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">📸 Foto Bukti Pengembalian</label>
                        <input type="file" name="return_proof" class="form-control" accept="image/png, image/jpeg" required>
                        <small class="text-danger">*Wajib diisi agar status berubah menjadi Selesai.</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Kirim Bukti & Selesai</button>
                </div>
            </form>
        </div>
    </div>
</div>
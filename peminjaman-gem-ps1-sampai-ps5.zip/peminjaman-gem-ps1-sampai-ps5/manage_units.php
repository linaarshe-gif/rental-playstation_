<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include 'auth.php';
require_staff(); // Hanya Admin & Petugas
include 'db.php';

$edit_mode = false;
$unit = ['id' => '', 'name' => '', 'generation' => 'Gen 5', 'price_per_day' => '', 'stock' => '', 'image_url' => ''];

// Jika mode edit
if (isset($_GET['edit'])) {
    $stmt = $conn->prepare("SELECT * FROM consoles WHERE id = ?");
    $stmt->bind_param("i", $_GET['edit']);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        $edit_mode = true;
        $unit = $res->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Unit - Rental PS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand mb-0 h1">📦 Kelola Unit (Admin/Petugas)</span>
        <div>
            <a href="index.php" class="btn btn-outline-light btn-sm me-2">Kembali ke Katalog</a>
            <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container">
    <div class="row">
        <!-- Form Tambah / Edit -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><?php echo $edit_mode ? 'Edit Unit' : 'Tambah Unit Baru'; ?></h5>
                </div>
                <div class="card-body">
                    <form action="process_unit.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="<?php echo $edit_mode ? 'edit' : 'add'; ?>">
                        <input type="hidden" name="id" value="<?php echo $unit['id']; ?>">
                        
                        <div class="mb-3">
                            <label class="form-label">Nama Konsol</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($unit['name']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Generasi</label>
                            <select name="generation" class="form-select" required>
                                <option value="Gen 1" <?php if($unit['generation']=='Gen 1') echo 'selected'; ?>>PlayStation 1</option>
                                <option value="Gen 2" <?php if($unit['generation']=='Gen 2') echo 'selected'; ?>>PlayStation 2</option>
                                <option value="Gen 3" <?php if($unit['generation']=='Gen 3') echo 'selected'; ?>>PlayStation 3</option>
                                <option value="Gen 4" <?php if($unit['generation']=='Gen 4') echo 'selected'; ?>>PlayStation 4</option>
                                <option value="Gen 5" <?php if($unit['generation']=='Gen 5') echo 'selected'; ?>>PlayStation 5</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Harga per Hari (Rp)</label>
                            <input type="number" name="price_per_day" class="form-control" value="<?php echo $unit['price_per_day']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Stok Awal</label>
                            <input type="number" name="stock" class="form-control" value="<?php echo $unit['stock']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Gambar Konsol</label>
                            <input type="file" name="image" class="form-control" accept="image/png, image/jpeg, image/webp">
                            <small class="text-muted">Maksimal 2MB. Kosongkan jika tidak ingin mengubah.</small>
                            <?php if ($edit_mode && !empty($unit['image_url']) && file_exists($unit['image_url'])): ?>
                                <img src="<?php echo htmlspecialchars($unit['image_url']); ?>" class="img-thumbnail mt-2" style="max-height: 100px;">
                            <?php endif; ?>
                        </div>
                        
                        <button type="submit" class="btn btn-success w-100"><?php echo $edit_mode ? 'Update Unit' : 'Simpan Unit'; ?></button>
                        <?php if ($edit_mode): ?>
                            <a href="manage_units.php" class="btn btn-secondary w-100 mt-2">Batal</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <!-- Tabel Daftar Unit -->
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-secondary text-white">
                    <h5 class="mb-0">Daftar Semua Unit</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Gambar</th>
                                    <th>Nama</th>
                                    <th>Harga</th>
                                    <th>Stok</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $result = $conn->query("SELECT * FROM consoles ORDER BY id ASC");
                                while ($row = $result->fetch_assoc()):
                                    $img = (!empty($row['image_url']) && file_exists($row['image_url'])) ? $row['image_url'] : 'https://via.placeholder.com/80x60?text=No+Img';
                                    $status_badge = $row['is_visible'] ? 'bg-success' : 'bg-secondary';
                                    $status_text = $row['is_visible'] ? 'Tampil' : 'Disembunyikan';
                                ?>
                                <tr class="<?php echo $row['is_visible'] ? '' : 'table-light text-muted'; ?>">
                                    <td><img src="<?php echo htmlspecialchars($img); ?>" class="img-thumbnail" style="max-height: 60px;"></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($row['name']); ?></strong><br>
                                        <small><?php echo htmlspecialchars($row['generation']); ?></small>
                                    </td>
                                    <td>Rp <?php echo number_format($row['price_per_day'], 0, ',', '.'); ?></td>
                                    <td><?php echo $row['stock']; ?></td>
                                    <td><span class="badge <?php echo $status_badge; ?>"><?php echo $status_text; ?></span></td>
                                    <td>
                                        <a href="manage_units.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning" title="Edit">✏️</a>
                                        <a href="process_unit.php?action=toggle&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-info text-white" title="<?php echo $row['is_visible'] ? 'Sembunyikan' : 'Tampilkan'; ?>">
                                            <?php echo $row['is_visible'] ? '👁️' : '👁️‍🗨️'; ?>
                                        </a>
                                        <a href="process_unit.php?action=delete&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus unit ini secara permanen?')" title="Hapus">🗑️</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>